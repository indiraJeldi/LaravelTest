<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTradesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('trades', function (Blueprint $table) {

            $table->increments('id');
            $table->string('trade');
            $table->integer('user_id')->unsigned();
            $table->integer('shares');
            $table->string('symbol');
            $table->decimal('price',8,2);
            $table->foreign('trade')->references('name')->on('trade_types')->onDelete('cascade');;
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');;
            $table->foreign('symbol')->references('name')->on('stocks')->onDelete('cascade');;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('trades');
    }
}
