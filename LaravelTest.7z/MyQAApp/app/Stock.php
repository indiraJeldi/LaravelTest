<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:26 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;


class Stock extends Model
{
    /**
     * The name of the "updated at" column.
     *
     * @var string
     */
    const UPDATED_AT = null;

    /**
     * The name of the "created at" column.
     *
     * @var string
     */
    const CREATED_AT = null;

    public function trades(){
        return $this->hasMany('App\Trade');
    }

    public function setUpdatedAt($value)
    {
        // Do nothing.
    }

    public function setCreateddAt($value)
    {
        // Do nothing.
    }

    public function stockPrices(){
        return $this->hasMany('App\StockPrices');
    }
}

