<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/', function () use ($app) {
    return $app->version();
});

/***
* The first parameter 'createuser' it is the url address
* So to call this we will use the URL as BASE URL + createuser
*
 * The second parameter is UserController@create
* it means we are calling create function which is inside UserController
*
 * Using the same for all routes
***/
$app->post('/createuser', 'UserController@create');
$app->post('/createtradetype', 'TradeTypeController@create');
$app->post('/createstock', 'StockController@create');
$app->post('/createstockprice', 'StockPriceController@create');
$app->get('/stocks/{name}/price', 'StockPriceController@getStocks');
$app->get('/stocks/stats', 'StockPriceController@getStockStats');
$app->post('/createtrades', 'TradeController@create');

/*$app->post('/createtrade', 'TradeController@create');*/
//$app->get('/categories', 'CategoryController@get');
//$app->get('/getmyquestions/{user_id}', 'UserController@getQuestions');
//$app->get('/questions', 'QuestionController@getAll');
//$app->get('/questions/{category_id}', 'QuestionController@getByCategory');
