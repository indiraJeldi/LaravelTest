<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:30 AM
 */

namespace App\Http\Controllers;

use App\TradeType;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;


class TradeTypeController extends Controller
{
    /**
     * @param Request $request
     * @return array
     */
    public function create(Request $request){

        $validator = Validator::make($request->all(), [
            'name'=>'required|unique:trade_types'
        ]);

        if($validator->fails()){
            return array(
                'error' => true,
                'message' => $validator->errors()->all()
            );
        }

        $tradeType = new TradeType();
        $tradeType->name = $request->input('name');
        $tradeType->save();

        return array('error'=>false, 'trade_type'=>$tradeType);
    }

}