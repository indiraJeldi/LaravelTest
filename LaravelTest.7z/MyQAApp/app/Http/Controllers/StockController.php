<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:30 AM
 */

namespace App\Http\Controllers;

use App\Stock;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class StockController extends Controller
{
    /**
     * @param Request $request
     * @return array
     */
    public function create(Request $request){

        $validator = Validator::make($request->all(), [
            'name'=>'required|unique:stocks'
        ]);

        if($validator->fails()){
            return array(
                'error' => true,
                'message' => $validator->errors()->all()
            );
        }
        
        $stock = new Stock();
        $stock->name = $request->input('name');
        $stock->save();

        return array('error'=>false, 'stock'=>$stock);
    }
    
}