<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:29 AM
 */

namespace App\Http\Controllers;

use App\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class TradeController extends Controller
{
    /**
     * @param Request $request
     * @return array
     */
    public function create(Request $request){

        $validator = Validator::make($request->all(), [
            'trade'=>'required',
            'user_id'=>'required',
            'symbol'=> 'required',
            'shares' => 'required|max:30|min:15',
            'price' => 'required|min:130.42|max:195.65'
        ]);

        if($validator->fails()){
            return array(
                'error' => true,
                'message' => $validator->errors()->all()
            );
        }

        $trade = new Trade;
        $trade->trade = $request->input('trade');
        $trade->user_id= $request->input('user_id');
        $trade->symbol = $request->input('symbol');
        $trade->shares = $request->input('shares');
        $trade->price = $request->input('price');

        $trade->save();
        return array('error'=>false, 'trade'=>$trade);
    }

    /**
     * Get All Trades
     */
    public function getAllTrades() {


    }

    /**
     * Get Trades By User
     * @param $userId
     * @return array
     */
    public function getByUser($userId){
        try{
            $trades = User::findOrFail($userId)->user;

            foreach($trades as $trade){
                
            }

            return array('error'=>false, 'trade'=>$trades);
        }catch(ModelNotFoundException $e){
            return array('error'=>true, 'message'=>'Invalid User ID');
        }
    }

}