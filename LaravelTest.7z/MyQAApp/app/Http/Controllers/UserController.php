<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:29 AM
 */

namespace App\Http\Controllers;

use Illuminate\Hashing\BcryptHasher;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\User;


class UserController extends Controller
{

    /**
     * this function is used to register a new user
     * @param Request $request
     * @return array
     */
    public function create(Request $request)
    {
        //creating a validator                                              
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:users',
        ]);

        //if validation fails
        if ($validator->fails()) {
            return array(
                'error' => true,
                'message' => $validator->errors()->all()
            );
        }

        //creating a new user
        $user = new User();

        //adding values to the users
        $user->name = $request->input('name');

        //saving the user to database
        $user->save();
        
        //returning the registered user
        return array('error' => false, 'user' => $user);
    }
    
}