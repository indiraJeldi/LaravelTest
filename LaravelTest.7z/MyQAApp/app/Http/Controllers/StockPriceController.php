<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:30 AM
 */

namespace App\Http\Controllers;

use App\StockPrice;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class StockPriceController extends Controller
{
    /**
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function index() {

        $stockPrices = StockPrice::all();
        return response()->json($stockPrices);
    }

    /**
     * @param Request $request
     * @return array
     */
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_price' => 'required',
            'symbol'=>'required',
        ]);

        if($validator->fails()){
            return array(
                'error' => true,
                'message' => $validator->errors()->all()
            );
        }

        $stockPrice = new StockPrice();
        $stockPrice->current_price = $request->input('current_price');
        $stockPrice->symbol = $request->input('symbol');
        $stockPrice->save();

        return array('error'=>false, 'stock_prices'=>$stockPrice);
    }

    /**
     * Get Stock prizes
     */
    public function getStocks($name)
    {
        $startDate = isset($_GET['start'])? $_GET['start'] : date('Y-m-d', strtotime(' -1 day'));
        $endDate = isset($_GET['end'])? $_GET['end']: date('Y-m-d');
        $stockPrice =  \DB::table('stock_prices')
            ->select('stocks.name', \DB::raw("MAX(stock_prices.current_price) AS highest"), \DB::raw("MIN(stock_prices.current_price) AS lowest"))
            ->join('stocks', 'stock_prices.symbol', '=', 'stocks.name')
            ->where( 'stock_prices.symbol', '=', $name) ;

        $stockPrice->where('stock_prices.created_at', '<=', $startDate);
        $stockPrice->where('stock_prices.updated_at', '>=', $endDate);
        $stockPrice->groupBy('stocks.name');
        $stockPrice->get();

        return response()->json($stockPrice);
    }

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getStockStats()
    {
        $startDate = isset($_GET['start'])? $_GET['start'] : date('Y-m-d', strtotime(' -1 day'));
        $endDate = isset($_GET['end'])? $_GET['end']: date('Y-m-d');
        $stockPrice =  \DB::table('stock_prices')
            ->select('stocks.name', 'stock.current_prices', \DB::raw("count(stock.name) AS fluctuations"))
            ->join('stocks', 'stock_prices.symbol', '=', 'stocks.name');
        $stockPrice->where('stock_prices.created_at', '<=', $startDate);
        $stockPrice->where('stock_prices.updated_at', '>=', $endDate);
        $stockPrice->groupBy('stocks.name');
        $stockPrice->get();

        return response()->json($stockPrice);
    }
    
}