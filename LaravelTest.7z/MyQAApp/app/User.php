<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{

    public function trades(){
        return $this->hasMany('App\Trade');
    }

    public  function stocks() {
        return $this->hasMany('App\Stock');
    }
}