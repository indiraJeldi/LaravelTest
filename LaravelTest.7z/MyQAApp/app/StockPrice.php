<?php
/**
 * Created by PhpStorm.
 * User: ij
 * Date: 1/11/2019
 * Time: 12:26 AM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;


class StockPrice extends Model
{
    public function trades(){
        return $this->hasMany('App\Trade');
    }
}

